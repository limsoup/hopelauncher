# SnapEditor License Agreement

Copyright (c) 2012 by 8098182 Canada Inc.

For full details of the SnapEditor License Agreement, please visit [http://snapeditor.com/license_agreeement](http://snapeditor.com/license_agreement).
